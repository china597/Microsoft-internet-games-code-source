/*
    ZoneIcons.h

    File describing the Zone Icons and their use.


    Blue    -- default icon; ZoneFriends, ZSetup
    Black   -- reserved
    Brown   -- Chat, TheaterChat
    Green   -- CB Games
    Gray    -- utilities; ZSysmon
    Purple  -- Rooms (CB and retail -- lobby.exe)
    Red     -- Launchpad
    Aqua    -- ZoneMessage
*/
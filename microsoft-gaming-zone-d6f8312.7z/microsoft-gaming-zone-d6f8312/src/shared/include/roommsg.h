#ifndef __ROOMMSG_H
#define __ROOMMSG_H

#ifndef _ROOM_
#define _ROOM_
#endif

#include "gamemsg.h"


#endif //__ROOMMSG_H
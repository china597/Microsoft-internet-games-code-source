//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\millennium\RESOURCES\Reversi\generic\ReversiRes.rc
//
#define IDB_REV_BLACK                   13101
#define IDB_REV_WHITE                   13102
#define IDB_REV_BLACKNAME               13103
#define IDB_REV_WHITENAME               13104
#define IDB_REV_BLACKMARK               13105
#define IDB_REV_WHITEMARK               13106
#define IDB_REV_BLACKCNT                13107
#define IDB_REV_WHITECNT                13108
#define IDB_RESULTS                     13109
#define IDB_BUTTON                      13112
#define IDD_BADMOVE                     13113
#define IDC_COMFORT                     13114
#define IDR_REVERSIACCELERATOR          13120
#define IDC_RESIGN_BUTTON               13150
#define IDC_GAME_WINDOW                 13152
#define IDC_RESULT_WINDOW               13153
#define IDS_BUTTON_RESIGN               13201
#define IDS_YOUR_TURN                   13204
#define IDS_OPPONENTS_TURN              13205
#define IDS_BLACKS_TURN                 13206
#define IDS_PLAYER_WINS                 13207
#define IDS_DRAW                        13209
#define IDS_RESIGN_CONFIRM              13214
#define IDS_RESIGN_CONFIRM_CAPTION      13215

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        13250
#define _APS_NEXT_COMMAND_VALUE         13500
#define _APS_NEXT_CONTROL_VALUE         13700
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

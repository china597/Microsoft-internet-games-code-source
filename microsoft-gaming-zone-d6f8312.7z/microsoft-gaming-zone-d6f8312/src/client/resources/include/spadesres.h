//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by E:\ZM\RESOURCES\spades\generic\SpadesRes.rc
//
#define IDB_OBJECTS                     10100
#define IDB_CARDBACK                    10101
#define IDB_GAMEOVERBACKGROUND          10108
#define IDB_HANDOVERBACKGROUND          10109
#define IDB_BIDDINGOBJECTS              10127
#define IDS_DOUBLENILBIDSTR             10203
#define IDS_PLAY                        10205
#define IDS_AUTOPLAY                    10207
#define IDS_STOP                        10208
#define IDS_SCORE                       10209
#define IDS_LASTTRICK                   10210
#define IDS_TEAM1NAME                   10211
#define IDS_TEAM2NAME                   10212
#define IDS_CANTLEADSPADES              10213
#define IDS_MUSTFOLLOWSUIT              10214
#define IDS_TRICKCOUNTER                10216
#define IDS_DONE                        10217
#define IDS_SELECTCARD                  10223
#define IDS_HANDSCORE_TITLE             10253
#define IDS_HANDSCORE_TRICKS            10254
#define IDS_HANDSCORE_NBAGS             10255
#define IDS_HANDSCORE_TRACT             10256
#define IDS_HANDSCORE_BONUS             10257
#define IDS_HANDSCORE_NIL               10258
#define IDS_HANDSCORE_BAGS              10259
#define IDS_GAMEOVER_TITLE              10260
#define IDS_BIDDING_SHOWCARDS           10261
#define IDS_BIDDING_DOUBLENIL           10262
#define IDS_BIDDING_OPENTEXT            10263
#define IDS_BIDDING_CHOOSETEXT          10264
#define IDS_BIDDING_NIL                 10265
#define IDS_HISTORY_HANDS               10266
#define IDS_HISTORY_TOTAL               10267
#define IDS_SPADES_YOU                  10268
#define IDI_BAG                         10600
#define IDI_BLANK                       10601
#define IDI_SPADE                       10602
#define IDD_SCORES                      10603
#define IDC_SCORES_TEAM1HANDS           10607
#define IDC_SCORES_TEAM2HANDS           10608
#define IDR_SPADES_ACCELERATOR_DONE     10699
#define IDR_SPADES_ACCELERATOR_DOUBLE   10700
#define IDC_LAST_TRICK_BUTTON			10701
#define IDC_SCORE_BUTTON				10702
#define IDC_PLAY_BUTTON					10703
#define IDC_AUTOPLAY_BUTTON				10704
#define IDC_STOP_BUTTON					10705
#define IDC_DONE_BUTTON					10706
#define IDC_SHOW_CARDS_BUTTON			10708
#define IDC_DOUBLE_NIL_BUTTON			10709
#define IDC_HAND                        10710
#define IDC_CLOSE_BOX                   10711


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        10129
#define _APS_NEXT_COMMAND_VALUE         10261
#define _APS_NEXT_CONTROL_VALUE         10531
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

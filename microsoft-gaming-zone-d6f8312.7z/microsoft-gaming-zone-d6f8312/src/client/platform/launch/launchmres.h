#ifndef __LAUNCHRESM_H
#define __LAUNCHRESM_H

#define IDS_FAILED 		1
#define IDS_CAPTION 	2
#define IDS_GAME 	    3
#define IDS_SERVER     	4
#define IDS_CMD		 	5




#endif


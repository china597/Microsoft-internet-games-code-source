//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ZoneClient.rc
//
#define IDD_EVENTSPY                    2302
#define IDD_DSVIEWER                    2303
#define IDR_DEBUG_MENU                  2400
#define IDSPY_CLEAR                     2523
#define IDSPY_EVENT                     2524
#define IDSPY_EVENTS                    2525
#define IDSPY_FIRE                      2526
#define IDSPY_GROUP                     2527
#define IDSPY_LIST                      2528
#define IDSPY_PRIORITY                  2529
#define IDSPY_USER                      2530
#define IDC_DSVIEWER_LIST               2550
#define IDC_DSVIEWER_TREE               2551
#define ID_DEBUG_DATASTOREVIEWER        2650
#define ID_DEBUG_EVENTSPY               2651

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        236
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif

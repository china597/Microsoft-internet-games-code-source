// LobbyWindow.cpp : Implementation of CLobbyWindow

#include "stdafx.h"
#include "ClientIDL.h"
#include "LobbyWindow.h"

/////////////////////////////////////////////////////////////////////////////
// CLobbyWindow


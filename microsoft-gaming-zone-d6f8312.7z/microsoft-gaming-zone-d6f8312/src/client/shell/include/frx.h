#ifndef __WINFRX_H__
#define __WINFRX_H__

#include "..\WinFrx\wndfrx.h"
#include "..\WinFrx\buttonfrx.h"
#include "rectfrx.h"
#include "..\WinFrx\palfrx.h"
#include "..\WinFrx\dibfrx.h"
#include "..\WinFrx\dirtyfrx.h"
#include "..\WinFrx\spritefrx.h"
#include "..\WinFrx\wndrectfrx.h"

#endif //!__WINFRX_H__

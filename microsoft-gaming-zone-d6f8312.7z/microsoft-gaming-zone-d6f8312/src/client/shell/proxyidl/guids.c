//
// Stupid build environment doesn't know how to
// compile a file in a different directory.
//
#include "ZoneProxy_i.c"

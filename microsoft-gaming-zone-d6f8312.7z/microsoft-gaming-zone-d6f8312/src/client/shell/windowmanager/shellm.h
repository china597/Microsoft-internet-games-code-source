#ifndef __SHELLM_H
#define __SHELLM_H

/******************************************************************************
 *
 * Copyright (C) 1998-1999 Microsoft Corporation.  All Rights reserved.
 *
 *****************************************************************************/

#pragma once

#define MS_STATE1 	1
#define MS_STATE2 	2
#define MS_STATE3 	3




#endif __SHELLM_H
